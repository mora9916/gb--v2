import { Component, OnInit } from '@angular/core';
import { ProductResponse } from '../../../core/types/Products';
import { ProductsCardComponent } from '../../products/products-card/products-card.component';
import { ProductsService } from '../../../core/services/products/products.service';
import { PlaceholderComponent } from '../../shared/placeholder/placeholder.component';
import {MatPaginatorModule, PageEvent} from '@angular/material/paginator';

@Component({
  selector: 'app-product-list',
  imports: [ProductsCardComponent, PlaceholderComponent, MatPagiatorModule],
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css'
})
export class ProductListComponent implements OnInit{
  productResponse!:ProductResponse;

  constructor(private productsService: ProductsService){}
  ngOnInit(): void {
    this.getProducts();
  }

  getProducts(page:number=1, limit:number=10){
    this.productsService.getProducts(page, limit).subscribe({
      next:(data)=>{
        console.log(data);
        this.productResponse = data;
      },
      error:(error) =>{
        console.log(error);
      }
    });
  }
  onPageChange(event: PageEvent){
    console.log(event);
    this.getProducts(event.pageIndex, event.pageSize);
  }
}
